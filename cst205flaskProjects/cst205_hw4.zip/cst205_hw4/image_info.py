image_info = [
  {
    "id" : "3260578960_43b778eb8b_c",
    "title" : "Matmata",
    "flickr_user" : "Sek Keung Lo",
    "tags" : ["Tunisia", "village", "cave", "dwelling"],
    "url" : "https://www.flickr.com/photos/losk/3260578960"
  },
  {
    "id" : "7882981302_aeb2bb0c8a_c",
    "title" : "Longyearbyen",
    "flickr_user" : "James Stringer",
    "tags" : ["Svalbard", "Norway", "vessel", "expedition"],
    "url" : "https://www.flickr.com/photos/jamesstringer/7882978164"
  },
  {
    "id" : "3308779370_2b278af584_c",
    "title" : "Árido",
    "flickr_user" : "David Campbell",
    "tags" : ["Mossoró", "Brazil", "salt", "petroleum", "arid"],
    "url" : "https://www.flickr.com/photos/davidsurfer/3308779370"
  },
  {
    "id" : "33878789960_0bfdc8a818_c",
    "title" : "Jūrmalas lidosta",
    "flickr_user" : "Kārlis Dambrāns",
    "tags" : ["Jūrmala,", "airport", "Latvia", "Tukums", "building"],
    "url" : "https://www.flickr.com/photos/janitors/33878789960"
  },
  {
    "id" : "12781079433_f66f128d11_c",
    "title" : "Sanaga River",
    "flickr_user" : "canonim",
    "tags" : [ "Cameroon", "Africa", "bridge", "motorcycle", "road", "overcast"],
    "url" : "https://www.flickr.com/photos/canad/12781079433/"
  },
  {
    "id" : "12943572274_44afbcaa5d_c",
    "title" : "Kunlun Mountain",
    "flickr_user" : "pacman321",
    "tags" : ["Yecheng", "landscape", "horizon", "China", "mountains", "overcast"],
    "url" : "https://www.flickr.com/photos/mzhang88/12943572274"
  },
  {
    "id" : "6277422540_2c19365479_c",
    "title" : "Menara Gardens and Pavilion",
    "flickr_user" : "sofianeb",
    "tags" : ["Marrakesh", "Morocco", "olives", "peaceful", "purple", "reservoir"],
    "url" : "https://www.flickr.com/photos/sofianeb/6277422540"
  },
  {
    "id" : "48960061001_1ca2a20a7d_c",
    "title" : "Zaisan Memorial",
    "flickr_user" : "Ronald Woan",
    "tags" : ["Ulaanbaatar", "Mongolia", "capital", "buildings", "roads", "hills"],
    "url" : "https://www.flickr.com/photos/rwoan/48960061001"
  },
  {
    "id" : "2695514097_0647b18812_c",
    "title" : "River in Vitebsk",
    "flickr_user" : "Kirill Afonin",
    "tags" : ["Belarus", "monument", "bayonet", "victory", "grass"],
    "url" : "https://www.flickr.com/photos/killerbass/2695514097"
  },
  {
    "id" : "2152601472_55fb809919_c",
    "title" : "Bulevardul Libertatii",
    "flickr_user" : "megatick",
    "tags" : ["Bucharest", "Romania", "boulevard", "road", "building", "overcast", "grass"],
    "url" : "https://www.flickr.com/photos/megatick/2152601472"
  }
]